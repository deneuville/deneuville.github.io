from random import randint, shuffle
from hashlib import sha512

def hammingWeight(v):
	return len(v)-v.count(0)

def randomVectOfFixedWeight(w,n):
	v=[1]*w + [0]*(n-w)
	shuffle(v)
	return v

def multiply(u, v):
	if len(u)!=len(v):
		print("bad dimensions")
		return
	n=len(u)
	result=[0]*n
	for i in range(n):
		if u[i]!=0:
			for j in range(n):
				if v[j]!=0:
					result[(i+j)%n] = (result[(i+j)%n] + u[i]*v[j])%2
	return result
	
def vectorMatrixMultiplyNoRed(u,M):
	k = len(u)
	if k!=len(M):
		print("dimensions mismatch")
		return
	c = len(M[0])
	result=[0 for _ in range(c)]
	for i in range(c):
		for j in range(k):
			result[i] += u[j]*M[j][i]
	return result


def matrixVectorMultiply(M,v):
	n=len(v)
	k=len(M)
	if k==0:
		print("Bad matrix M")
		return
	m=len(M[0])
	if m!=n:
		print("dimensions mismatch")
		return
	result=[0 for _ in range(k)]
	for i in range(k):
		for j in range(n):
			result[i] = (result[i] + v[j]*M[i][j])%2
	return result

def add(u, v):
	if len(u)!=len(v):
		print("dimensions mismatch")
		return
	return [(u[i]+v[i])%2 for i in range(len(u))]

def hash(w, n, u, v):
    r = int(sha512((str(u)+str(v)).encode('utf-8')).hexdigest(), base=16)
    s = set()
    while len(s) < w and r != 0:
        s.add(r%n)
        r = r//n
    lst = n*[0]
    for ele in s:
        lst[ele] = 1
    return lst

def genH(u, v):
	n=len(u)
	H=[[0 for _	in range(2*n)] for _ range(n)]
	for i in range(n):
		for j in range(n):
			H[i][j  ]=u[(i-j)%n]
			H[i][n+j]=v[(i-j)%n]
	return H
