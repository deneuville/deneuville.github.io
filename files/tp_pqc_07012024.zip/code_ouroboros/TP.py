#!/usr/bin/python3
# -*- coding: utf-8 -*-

from routines import *

def keygen(w, we, n):
	pass

def encapsulate(h, s, w, we, n):
	pass

def decapsulate(x, y, h, s, w, we, n, sr, se, T):
	pass

def extendedBitFlipping(x, y, s, t, w, we):
	pass

w=47
we=2*w
n=5851
t=30
