from random import randint, shuffle
from hashlib import sha512

def randomVectOfFixedWeight(w,n):
	pass

def multiply(u, v):
	pass
	
def add(u, v):
	pass

def vectorMatrixMultiplyNoRed(u,M):
	pass

def matrixVectorMultiply(M,v):
	pass

def hash(w, n, u, v):
    r = int(sha512((str(u)+str(v)).encode('utf-8')).hexdigest(), base=16)
    s = set()
    while len(s) < w and r != 0:
        s.add(r%n)
        r = r//n
    lst = n*[0]
    for ele in s:
        lst[ele] = 1
    return lst

def genH(u, v):
	pass
